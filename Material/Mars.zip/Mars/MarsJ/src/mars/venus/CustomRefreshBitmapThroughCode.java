package mars.venus;

import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.KeyStroke;
import mars.Globals;
import static mars.tools.BitmapDisplay.Grid.aux;
import static mars.tools.BitmapDisplay.Grid.columns;
import static mars.tools.BitmapDisplay.Grid.grid;
import static mars.tools.BitmapDisplay.Grid.rows;

public class CustomRefreshBitmapThroughCode extends GuiAction
{
    public CustomRefreshBitmapThroughCode(String name, Icon icon, String descrip, Integer mnemonic, KeyStroke accel, VenusUI gui)
    {
	super(name, icon, descrip, mnemonic, accel, gui);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
	boolean visibility = ((JCheckBoxMenuItem) e.getSource()).isSelected();
	Globals.getSettings().setChangeRefreshBitmap(visibility);

	if (visibility)
	{
	    for (int i = 0; i < rows; i++)
	    {
		System.arraycopy(grid[i], 0, aux[i], 0, columns);
	    }
	}
    }
}
